$(document).ready(
	function(){
	$('div.loading').show();
});
