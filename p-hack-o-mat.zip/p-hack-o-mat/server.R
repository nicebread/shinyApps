library(shiny)
library(shinyTable)
library(stringr)
library(dplyr)
library(ggplot2)
library(xtable)
source("helpers.R")

#input <- list(n_new=20, true_effect=1, label_group1="A", label_group2="B", DV_selector = "DV1", cov_gender_IA=FALSE, cov_gender=FALSE, cov_age=TRUE);dat <- list()


# get random dat from contaminated normal (see Wilcox & Keselman, 2003)
rnorm.cont <- function(n, mean = 0, sd = 1, mean.cont = 0, sd.cont=3, frac.cont=0.1) {
	frac.n <- round(n*frac.cont)
	x <- c(rnorm(n-frac.n, mean, sd), rnorm(frac.n, mean.cont, sd.cont))
	
	# shuffle x
	x2 <- x[sample(n, n)]
	return(x2)
}

# returns a data frame of two variables which correlate
# If desired, one of variables can be fixed to an existing variable by specifying x. This, however, should only be done with normally distributed variables!
getBiCop <- function(n, rho, mar.fun=rnorm, x = NULL, ...) {
	if (!is.null(x)) {X1 <- x} else {X1 <- mar.fun(n, ...)}
	if (!is.null(x) & length(x) != n) warning("Variable x does not have the same length as n!")
	
	C <- matrix(rho, nrow = 2, ncol = 2)
	diag(C) <- 1
	
	C <- chol(C)

	X2 <- mar.fun(n)
	X <- cbind(X1,X2)

	# induce correlation (does not change X1)
	df <- X %*% C
	
	## if desired: check results
	#all.equal(X1,X[,1])
	#cor(X)

	return(df)
}

shinyServer(function(input, output, session) {
	
	dat <- reactiveValues(
		currentData = data.frame(),
		n	= 0,
		n_studies = 0,					# number of studies in stack
		studystack=""
	)
	
	observe({
		# TODO: If the "Interaction with gender" box is clicked, the "control for gender" box should be checked too
		if (input$cov_gender_IA == TRUE) {
			input$cov_gender == TRUE
		}
	})
	
	# ---------------------------------------------------------------------
	#  generate new data
	observe({
		
		#print("Generating new data")
		# only react on button press
		if (input$generateNewData==0) return();	
			
		# if a seed is set: Use this, and increase it, so that the next data generation gets different numbers
		isolate({
			if (input$seed != "") {			
					seed <- as.numeric(input$seed)
					set.seed(seed)
					updateTextInput(session, "seed", value=seed+1)			
			}
		})
			
		# reset the settings from the p-hacking tab
		updateCheckboxInput(session, "cov_age", value=FALSE)
		updateCheckboxInput(session, "cov_gender", value=FALSE)
		updateCheckboxInput(session, "cov_gender_IA", value=FALSE)
		updateSelectInput(session, "DV_selector", selected = "DV1")
		
		isolate({
			# simulate study with N participants (not all are included in analysis)
			N <- 10000
			dat$n <- input$n_new

			DV1 <- scale(rnorm(N*2, 0, 1))
			
			dat$currentData <- data.frame(
				group = factor(rep(c(input$label_group1, input$label_group2), N)),
				DV1 = DV1,
				DV2 = scale(getBiCop(N*2, rho=0.5, x=DV1, mar.fun=rnorm)[, 2]),
				DV3 = scale(getBiCop(N*2, rho=0.5, x=DV1, mar.fun=rnorm)[, 2]),
				age = round(rgamma(N*2, 4, 0.5) + 18),
				gender = factor(sample(0:1, N*2, replace=TRUE), labels=c("male", "female"))
			)
			
			# add fixed effect to one group
			dat$currentData[dat$currentData$group==input$label_group1, "DV1"] <- 
				dat$currentData[dat$currentData$group==input$label_group1, "DV1"] + input$true_effect
			dat$currentData[dat$currentData$group==input$label_group1, "DV2"] <- 
				dat$currentData[dat$currentData$group==input$label_group1, "DV2"] + input$true_effect
			dat$currentData[dat$currentData$group==input$label_group1, "DV3"] <- 
				dat$currentData[dat$currentData$group==input$label_group1, "DV3"] + input$true_effect
			dat$currentData$DV_all <- rowMeans(dat$currentData[, c("DV1", "DV2", "DV3")])
			
		}) # of isolate
		
		#print(summary(dat$currentData))
	})
	

	# run the test
	observe({
		#print("Computing test ...")
		
		if (nrow(dat$currentData)==0) return();
			
		# react on changes in n	
		dat$n
		
		control <- ""		
		if (input$cov_age == TRUE) control <- paste0(control, " + age")
		if (input$cov_gender == TRUE) control <- paste0(control, " + gender")
		if (input$cov_gender_IA == TRUE) control <- paste0(control, " + gender*group")
		
		isolate({
			dat$TEST <- list()	# keeps the aov objects for each DV
			dat$P <- list()		# stores p values for each DV
			for (DV in c("DV1", "DV2", "DV3", "DV_all")) {
				f <- formula(paste0(DV, " ~ group", control))
				dat$TEST[[DV]] <- aov(f, dat$currentData[1:(dat$n*2), ])
				dat$TEST[[DV]]$DV <- DV
				dat$P[[DV]] <- summary(dat$TEST[[DV]])[[1]]$Pr[1]
			}
			
			# automatically select the DV with the lowest p value
			updateSelectInput(session, "DV_selector", selected = names(which.min(dat$P)))			
		})
	})

	
	output$save_button <- renderUI({
	    actionButton("save_current_study", label = paste0("Save current study (", input$DV_selector, ") to stack"))
	  })

	
	output$testoverview <- renderUI({				
		
		if (is.null(dat$TEST[[1]])) {
			return(list(HTML("<h4>No study run yet - click on 'Run new experiment' at the bottom of the left panel!</h4>")))
		}
		
		#TEST_SUMMARY_TEX <- print(xtable(dat$TEST), 
		#	floating=FALSE, tabular.environment="array", 
		#	comment=FALSE, print.results=FALSE, sanitize.rownames.function = function(x){x})
					
		return(list(			
			HTML("<h2>Tests for each DV:</h2>"),		
			#tags$script(src = 'http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML', type = 'text/javascript'),	
			#HTML(paste0("$$", TEST_SUMMARY, "$$"))
			HTML(paste0('
				<div id="all" style="position: relative; overflow: hidden;">
			            <div id="DV1" style="margin-bottom:4px; background-color: ', colChoose(dat$P[[1]]), ';">',
			            formatAOV(dat$TEST[[1]])
			            ,'</div><br>
			            <div id="DV2" style="margin-bottom:4px; background-color: ', colChoose(dat$P[[2]]), ';">',
			            formatAOV(dat$TEST[[2]])
			            ,'</div><br>
			            <div id="DV3" style="margin-bottom:4px; background-color: ', colChoose(dat$P[[3]]), ';">',
			            formatAOV(dat$TEST[[3]])
			            ,'</div><br>
			            <div id="DV4" style="margin-bottom:4px; background-color: ', colChoose(dat$P[[4]]), ';">',
			            formatAOV(dat$TEST[[4]])
			            ,'</div><br>
			        </div>
			'))
		))	
	})



	output$scatterplot <- renderUI({
		
		if (is.null(dat$TEST[[1]])) return()
						
		# TODO: Interaction plot when interaction with gender is chosen
		p_overview <- NULL
		if (!is.null(dat$currentData)) {
			p_overview <- ggplot(dat$currentData[1:dat$n, ], aes_string(x="group", y=input$DV_selector)) + geom_point(position="jitter") + geom_boxplot(fill=NA)
		}
		
		return(list(
			HTML("<h2>Plot:</h2>"),
			renderPlot({p_overview})
		))
	})


	observe({
		input$add5
		isolate({dat$n <- dat$n + 5})
	})
	
	observe({
		input$add10
		isolate({dat$n <- dat$n + 10})
	})

	
	
	output$studystack<- renderUI({
		pchecker_link <- paste0("http://shinyapps.org/apps/p-checker/?syntax=", URLencode(dat$studystack, reserved=TRUE))

		return(list(
			h3("My study stack: Studies that worked!"),
			HTML(paste0('<textarea id="txt" rows="10" cols="45">', dat$studystack, '</textarea>')),
			HTML(paste0('<a class="btn btn-default" href = "', pchecker_link, '"  target="_blank">Send studies to p-checker!</a>'))
		))	
	})
	
	# ---------------------------------------------------------------------
	#  add current study to stack
	observe({
		if (is.null(input$save_current_study) || input$save_current_study==0) return();

		isolate({
			dat$n_studies <- dat$n_studies + 1
			dat$studystack <- paste0(
				dat$studystack,
				"hack-o-mat (", format(Sys.time(), "%Y"), ") S", dat$n_studies, ": ",
				"F(1, ", dat$TEST[[input$DV_selector]]$df.residual, ") = ", round(summary(dat$TEST[[input$DV_selector]])[[1]]$F[1], 2), "; p = ", round(summary(dat$TEST[[input$DV_selector]])[[1]]$Pr[1], 3), "\n"
				)
		})
	})
	
	
	# clear stack
	observe({
		if (input$clear_stack==0) return();

		isolate({
			dat$n_studies <- 0
			dat$studystack <- ""
		})
	})
})
