# simple wrapper: formats a number in f.2 format
f2 <- function(x, digits=2, prepoint=0, skipZero=FALSE) {	
	if (skipZero == TRUE) {zero <- "."} else {zero <- "0."}
	
	if (length(dim(x)) == 2) {
		apply(x, 2, function(x2) {gsub("0.", zero, sprintf(paste("%",prepoint,".",digits,"f",sep=""), x2) , fixed=TRUE)})
	} else {
		gsub("0.", zero, sprintf(paste("%",prepoint,".",digits,"f",sep=""), x) , fixed=TRUE)
	}
}


# nicely formats a p-value
p0 <- function(x, digits=3) {
	if (is.na(x)) return("NA")
	if (x >= .1^digits) return(paste0("<i>p</i> = ", f2(x, digits, skipZero=TRUE)))
	if (x <  .1^digits) return(paste0("<i>p</i> < ", f2(.1^digits, digits, skipZero=TRUE)))
}
p <- Vectorize(p0)

# formats the aov output to a convenient HTML string
formatAOV <- function(x) {
	paste0(
		x$DV, ": F(1, ", x$df.residual, ") = ", round(summary(x)[[1]]$F[1], 2),
		"; ", p(summary(x)[[1]]$Pr[1])		
	)
}

colChoose <- function(p) {
	if (p<=.05) return("#5AEB31")
	if (p>.05 & p <=.10) return("#EBF2D6")
	if (p>.10 & p <=.20) return("#F4F4F4")
	if (p>.20) return("none")
}