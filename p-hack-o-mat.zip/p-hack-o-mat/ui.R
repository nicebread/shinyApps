library(shiny)
library(shinythemes)
library(shinyTable)
library(shinyBS) # Additional Bootstrap Controls
source("helpers.R")

# Load the panels with the manual etc.
source("snippets/quick_start.R")
source("snippets/about.R")

shinyUI(fluidPage(theme = shinytheme("cosmo"),

	tags$head(tags$link(rel="stylesheet", type="text/css", href="accordion.css")),	
	
	title = "p-hacker: Train your p-hacking skills!",
	
	titlePanel("p-hacker: Train your p-hacking skills!"),
	
	HTML(paste0('<div class="row">', qs_panel, about_panel, '</div>')),	
	
	# ---------------------------------------------------------------------
	# The actual app ...
	
	fluidRow(
		column(width=4,
			tabsetPanel(id ="tabs1",				
				tabPanel("New study",	
					h2("Settings for initial data collection:"),			
					textInput("label_group1", "Name for experimental group", "Elderly priming"),
					textInput("label_group2", "Name for control group", "Control priming"),
					sliderInput("n_new", "Initial # of participants in each group", min=2, max=100, value=20, step=1),
					sliderInput("true_effect", "True effect in population", min=0, max=1.5, value=0, step=0.05),		
					actionButton('generateNewData','Run new experiment (and discard current data)!'),
					textInput("seed", "Seed", "1")
				),
				tabPanel("Now: p-hack!",	
					h2("Tools to improve your p-value:"),
					selectInput("DV_selector", "Select dependent variable you want to keep:", list("DV1", "DV2", "DV3", "Aggregate"="DV_all"), "DV1"),
			
					checkboxInput("cov_age", "Control for age", FALSE),
					checkboxInput("cov_gender", "Control for gender", FALSE),
					checkboxInput("cov_gender_IA", "Interaction with gender", FALSE),
		
					actionButton('add5','Add 5 new participants!'),
					actionButton('add10','Add 10 new participants!')
				)
			)
		),		
		
		
		# ---------------------------------------------------------------------
		# The output panels, on the right side
		
		column(width=5, 					
			htmlOutput("testoverview"),
			htmlOutput("scatterplot")
		),
		
		column(width=3,			
			htmlOutput("save_button"),					
			htmlOutput("studystack"),
			actionButton("clear_stack", "Clear stack")
		)
	)	
))
